/* #undef SDL_VENDOR_INFO */
#define SDL_REVISION_NUMBER 0

#ifdef SDL_VENDOR_INFO
#define SDL_REVISION "SDL-release-2.26.0-311-g9ed1b778e (" SDL_VENDOR_INFO ")"
#else
#define SDL_REVISION "SDL-release-2.26.0-311-g9ed1b778e"
#endif
